<?php
class Omise_Gateway_Checkout_TescoController extends Omise_Gateway_Controller_BaseBarcode
{
    
}
