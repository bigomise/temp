<?php
class Omise_Gateway_Block_Form_Offsitealipay extends Mage_Payment_Block_Form
{
    // Note that we need to have this class (even it's empty) as a reference for html block in checkout page.
}
