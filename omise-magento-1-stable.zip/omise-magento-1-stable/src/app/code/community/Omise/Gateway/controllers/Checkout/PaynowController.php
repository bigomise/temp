<?php
class Omise_Gateway_Checkout_PaynowController extends Omise_Gateway_Controller_BaseBarcode
{
    
}
